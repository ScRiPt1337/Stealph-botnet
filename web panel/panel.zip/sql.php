<?php
$servername = "localhost";
$username = "u251400708_brain";
$password = "golaghat";
$dbname = "u251400708_brain";


$conn = new mysqli($servername, $username, $password, $dbname);

