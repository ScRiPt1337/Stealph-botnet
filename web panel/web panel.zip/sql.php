<?php
$servername = "you database servere ";
$username = "you database username";
$password = "you database password";
$dbname = "you database name";


$conn = new mysqli($servername, $username, $password, $dbname);

